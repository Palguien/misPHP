<?php

namespace App\Controller;

use App\Entity\Pelicula;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Attribute\Route;
use App\Repository\PeliculaRepository;

#[Route('/pelicula', name: 'app_pelicula')]
final class PeliculaController extends AbstractController
{
    #[Route('/', name: 'index_pelicula')]
    public function index(): Response
    {
        return $this->json("Esta es la ruta index de pelicula");
    }
    //Ver las películas
    #[Route('/lista', name: 'lista_pelicula', methods: ['GET'])]
    public function peliculaList(EntityManagerInterface $emi): Response
    {
        //Llamada a la ruta: GET 127.0.0.1:8000/pelicula/lista
        $peliculas = $emi ->getRepository(Pelicula::class)->findAll();
        $peliculasJson=array();

        foreach ($peliculas as $pelicula) {
            $peliculasJson[]=[
                $pelicula->getTitulo(),
                $pelicula->getDescripcion(),
                $pelicula->getAnyo(),
                $pelicula->getDuracion()                
            ];
        }

        return $this->json($peliculasJson);
    }

    //Ver la pelicula
    #[Route('/{id}', name: 'ver_pelicula', methods: ['GET'])]
    public function peliculaVer(int $id, EntityManagerInterface $emi): Response
    {
        //Llamada a la ruta: GET 127.0.0.1:8000/pelicula/1
        $peliculas = $emi ->getRepository(Pelicula::class)->find($id);
        if(!$peliculas){
            return $this->json("La pelicula no existe");
        }
        $peliculasJson=array();
            $peliculasJson[]=[
                $peliculas->getTitulo(),
                $peliculas->getDescripcion(),
                $peliculas->getAnyo(),
                $peliculas->getDuracion()                
            ];

        return $this->json($peliculasJson);
    }

    //Ver las peliculas de un año concreto
    #[Route('/anyo/{year}', name: 'ver_pelicula', methods: ['GET'])]
    public function peliculaVerAnyo(int $year, EntityManagerInterface $emi): Response
    {
        //Llamada a la ruta: GET 127.0.0.1:8000/pelicula/anyo/2
        $peliculas = $emi ->getRepository(Pelicula::class)->findAll();
        if(!$peliculas){
            return $this->json("La pelicula no existe");
        }
        $peliculasJson=array();

        foreach ($peliculas as $pelicula) {
            if($pelicula->getAnyo() == $year){
                $peliculasJson[]=[
                    $pelicula->getTitulo(),
                    $pelicula->getDescripcion(),
                    $pelicula->getAnyo(),
                    $pelicula->getDuracion()                
                ];
            }
            
        }

        return $this->json($peliculasJson);
    }

    //registrar la pelicula
    #[Route('/registrar', name: 'registrar_pelicula', methods: ['POST'])]
    public function peliculaRegistrar(request $request, EntityManagerInterface $emi): Response
    {
        //1.Llamada a la ruta: POST 127.0.0.1:8000/pelicula/registrar
        //2.Pasar los datos de la pelicula nueva
        /*
        {
        "titulo": "Nueva peli",
        "descripcion": "Esta es la nueva peli guapa",
        "anyo": 2025,
        "duracion":90
        }
        */
        //3.Recibir los datos
        $body = $request -> getContent();
        $data = json_decode(json: $body, associative: true);
        //return $this -> json($data["titulo"]);
        //4.Registrar la peli en la BD
        $pelicula = new Pelicula();
            $pelicula -> setTitulo($data["titulo"]);
            $pelicula -> setDescripcion($data["descripcion"]);
            $pelicula -> setAnyo($data["anyo"]);
            $pelicula -> setDuracion(duracion: $data["duracion"]);

        $emi ->persist($pelicula);
        $emi ->flush();
        //5.Responder con peli creada
        return $this->json("Pelicula creada",Response::HTTP_CREATED);
        //return $this->json("Pelicula creada",201);
    }

    //borrar la pelicula
    #[Route('/borrar/{id}', name: 'borrar_pelicula', methods: ['DELETE'])]
    public function peliculaBorrar(int $id, EntityManagerInterface $emi): Response
    {
        //Llamada a la ruta: DELETE 127.0.0.1:8000/pelicula/borrar/1
        //Llamada a la ruta: DELETE 127.0.0.1:8000/pelicula/borrar/9
        $pelicula = $emi ->getRepository(Pelicula::class)->find($id);
        if(empty($pelicula)){
            return $this->json("La pelicula no existe");
        }else{
            $emi ->remove($pelicula);
            $emi ->flush();
        }
        

        return $this->json("Pelicula borrada",200);
    }

    # Modificar una pelicula
    #[Route('/mod/{id}', name: 'mod_pelicula')]
    public function mod_movie(int $id, EntityManagerInterface $emi, Request $request): Response
    {
        //Llamada a la ruta: POST 127.0.0.1:8000/pelicula/mod/1
        /*
        {
        "titulo": "Nueva peli modificada",
        "descripcion": "Esta es la nueva peli guapa",
        "anyo": 2025,
        "duracion":90
        }
        */
        $movie = $emi->getRepository(Pelicula::class)->find($id);

        if(empty($movie)){
            return $this->json("No existe esta pelicula en la BBDD");
        }

        $data = json_decode(json: $request -> getContent() , associative: true);
        if(isset($data["titulo"])){
            $movie -> setTitulo($data["titulo"]);
        }
        if(isset($data["descripcion"])){
            $movie -> setDescripcion($data["descripcion"]);
        }
        if(isset($data["duracion"])){
            $movie -> setDuracion($data["duracion"]);
        }
        if(isset($data["anyo"])){
            $movie -> setAnyo($data["anyo"]);
        }

        $emi ->persist($movie);
        $emi -> flush();

        return $this->json("Pelicula Actualizada");
    }
}
